package com.potpal.mirrortrack.ui

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import dagger.hilt.android.AndroidEntryPoint

/**
 * Single-activity host. Real navigation is deferred to a NavHost added once
 * UnlockScreen, LiveFeedScreen, and CategoryBrowser exist. This stub exists
 * only so the project compiles and runs; Claude Code should replace the body
 * with the unlock flow first, then the feed, then settings.
 */
@AndroidEntryPoint
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                Scaffold { padding ->
                    Column(Modifier.fillMaxSize().padding(padding)) {
                        PlaceholderContent()
                    }
                }
            }
        }
    }
}

@Composable
private fun PlaceholderContent() {
    Text("MirrorTrack — scaffold. Next: unlock flow → live feed → settings.")
}
