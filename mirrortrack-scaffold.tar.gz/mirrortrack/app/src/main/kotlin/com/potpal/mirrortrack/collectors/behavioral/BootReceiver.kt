package com.potpal.mirrortrack.collectors.behavioral

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
// import com.potpal.mirrortrack.scheduling.CollectionForegroundService

/**
 * On device boot, re-start the collection foreground service if the user
 * had it enabled prior to shutdown. State lives in DataStore.
 *
 * TODO: wire to DataStore flag + CollectionForegroundService.start(context)
 * once those exist.
 */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_BOOT_COMPLETED) return
        // CollectionForegroundService.startIfEnabled(context)
    }
}
