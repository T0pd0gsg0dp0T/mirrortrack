package com.potpal.mirrortrack.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import com.potpal.mirrortrack.data.entities.DataPointEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface DataPointDao {

    @Insert
    suspend fun insertAll(points: List<DataPointEntity>)

    @Query("SELECT * FROM data_points ORDER BY timestamp DESC LIMIT :limit")
    fun observeRecent(limit: Int = 500): Flow<List<DataPointEntity>>

    @Query(
        "SELECT * FROM data_points WHERE collectorId = :collectorId " +
            "ORDER BY timestamp DESC LIMIT :limit"
    )
    suspend fun byCollector(collectorId: String, limit: Int = 1000): List<DataPointEntity>

    @Query(
        "SELECT * FROM data_points WHERE category = :category " +
            "ORDER BY timestamp DESC LIMIT :limit"
    )
    suspend fun byCategory(category: String, limit: Int = 1000): List<DataPointEntity>

    @Query("SELECT COUNT(*) FROM data_points")
    suspend fun count(): Long

    @Query("SELECT COUNT(*) FROM data_points WHERE collectorId = :collectorId")
    suspend fun countByCollector(collectorId: String): Long

    /**
     * Retention cutoff. Deletes rows for a specific collector older than
     * `cutoffMs`. Called by the retention worker per-collector with that
     * collector's configured TTL.
     */
    @Query("DELETE FROM data_points WHERE collectorId = :collectorId AND timestamp < :cutoffMs")
    suspend fun purgeOlderThan(collectorId: String, cutoffMs: Long): Int

    @Query("DELETE FROM data_points")
    suspend fun purgeAll()
}
