package com.potpal.mirrortrack.collectors

import com.potpal.mirrortrack.collectors.behavioral.ScreenStateCollector
import com.potpal.mirrortrack.collectors.device.BuildInfoCollector
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import javax.inject.Inject
import javax.inject.Singleton

/**
 * The single source of truth for which collectors exist. To add a new
 * collector:
 *   1. Create the Collector implementation.
 *   2. Add it to the list in CollectorRegistryModule.provideCollectors.
 *   3. That's it. UI surfaces it automatically via CategoryBrowser.
 *
 * Rationale for the explicit list (vs. classpath scanning or @IntoSet):
 * explicit is auditable. Grep for "provideCollectors" and you see every
 * data source the app has. With multibinding sets, collectors can sneak
 * in via third-party modules — which is exactly what we don't want in a
 * self-surveillance tool.
 */
@Singleton
class CollectorRegistry @Inject constructor(
    private val collectors: List<@JvmSuppressWildcards Collector>
) {
    fun all(): List<Collector> = collectors
    fun byId(id: String): Collector? = collectors.firstOrNull { it.id == id }
    fun byCategory(category: Category): List<Collector> =
        collectors.filter { it.category == category }
}

@Module
@InstallIn(SingletonComponent::class)
object CollectorRegistryModule {

    @Provides
    @Singleton
    fun provideCollectors(
        buildInfo: BuildInfoCollector,
        screenState: ScreenStateCollector
        // Add new collectors here. Keep alphabetical within category.
    ): List<@JvmSuppressWildcards Collector> = listOf(
        buildInfo,
        screenState
    )
}
