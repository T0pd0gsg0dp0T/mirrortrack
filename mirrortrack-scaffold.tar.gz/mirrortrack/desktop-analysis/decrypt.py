#!/usr/bin/env python3
"""
Decrypt an exported MirrorTrack SQLCipher DB for desktop analysis.

Workflow on the phone:
  Settings > Export → produces mirrortrack_YYYYMMDD.db.enc + salt.bin

Workflow on desktop:
  $ python decrypt.py mirrortrack_20260417.db.enc salt.bin
  (prompts for passphrase)
  → writes mirrortrack_20260417.db (plain SQLite, readable by DuckDB/pandas)

Dependencies:
  pip install argon2-cffi pysqlcipher3

Note on pysqlcipher3: the binary wheel is flaky on some distros. If it fails
to install, the fallback is the sqlcipher CLI — see the commented block at
bottom.

Security note: this script leaves a *plaintext* SQLite file on disk. Keep it
on an encrypted partition or an encrypted USB drive. Delete with `shred -u`
when done. Your threat model may vary; plan accordingly.
"""

import argparse
import getpass
import sys
from pathlib import Path

from argon2.low_level import hash_secret_raw, Type


# Must match the values in CryptoManager.kt exactly.
ARGON2_T_COST = 3
ARGON2_M_COST_KIB = 65_536
ARGON2_PARALLELISM = 2
KEY_LENGTH_BYTES = 32


def derive_key(passphrase: str, salt: bytes) -> bytes:
    return hash_secret_raw(
        secret=passphrase.encode("utf-8"),
        salt=salt,
        time_cost=ARGON2_T_COST,
        memory_cost=ARGON2_M_COST_KIB,
        parallelism=ARGON2_PARALLELISM,
        hash_len=KEY_LENGTH_BYTES,
        type=Type.ID,
    )


def decrypt_with_pysqlcipher(enc_path: Path, key: bytes, out_path: Path) -> None:
    try:
        from pysqlcipher3 import dbapi2 as sqlcipher
    except ImportError:
        print("pysqlcipher3 unavailable — falling back to CLI path.", file=sys.stderr)
        decrypt_with_cli(enc_path, key, out_path)
        return

    hex_key = key.hex()
    con = sqlcipher.connect(str(enc_path))
    cur = con.cursor()
    cur.execute(f"PRAGMA key = \"x'{hex_key}'\"")
    cur.execute("PRAGMA cipher_compatibility = 4")
    cur.execute(f"ATTACH DATABASE '{out_path}' AS plain KEY ''")
    cur.execute("SELECT sqlcipher_export('plain')")
    cur.execute("DETACH DATABASE plain")
    con.close()


def decrypt_with_cli(enc_path: Path, key: bytes, out_path: Path) -> None:
    import subprocess
    hex_key = key.hex()
    script = f"""
PRAGMA key = "x'{hex_key}'";
PRAGMA cipher_compatibility = 4;
ATTACH DATABASE '{out_path}' AS plain KEY '';
SELECT sqlcipher_export('plain');
DETACH DATABASE plain;
"""
    subprocess.run(
        ["sqlcipher", str(enc_path)],
        input=script,
        text=True,
        check=True,
    )


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("enc_db", type=Path, help="Encrypted .db.enc export")
    ap.add_argument("salt", type=Path, help="salt.bin from the export bundle")
    ap.add_argument(
        "--out",
        type=Path,
        default=None,
        help="Output path for plaintext DB (default: strips .enc suffix)",
    )
    args = ap.parse_args()

    if not args.enc_db.exists():
        print(f"Encrypted DB not found: {args.enc_db}", file=sys.stderr)
        return 1
    if not args.salt.exists():
        print(f"Salt file not found: {args.salt}", file=sys.stderr)
        return 1

    out = args.out or args.enc_db.with_suffix("")
    if out.exists():
        print(f"Output {out} exists; refusing to overwrite.", file=sys.stderr)
        return 1

    salt = args.salt.read_bytes()
    if len(salt) != 16:
        print(f"Unexpected salt length {len(salt)} (want 16).", file=sys.stderr)
        return 1

    passphrase = getpass.getpass("DB passphrase: ")
    print("Deriving key (Argon2id, ~500ms)...", file=sys.stderr)
    key = derive_key(passphrase, salt)

    print(f"Decrypting {args.enc_db} -> {out}", file=sys.stderr)
    decrypt_with_pysqlcipher(args.enc_db, key, out)

    print(f"OK. Plaintext SQLite: {out}", file=sys.stderr)
    print(f"Quick peek: sqlite3 {out} 'SELECT COUNT(*) FROM data_points'", file=sys.stderr)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
